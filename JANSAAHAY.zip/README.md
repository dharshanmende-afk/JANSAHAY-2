# 🎓 JANSAAHAY (जनसहाय)
### National & Global Scholarship Discovery, Eligibility & Step-by-Step Application Platform

> **Author / Maintainer:** [dharshanmende-afk](https://github.com/dharshanmende-afk)  
> **Project Name:** `JANSAAHAY`  
> **Platform Target:** Responsive Mobile, Tablet & Desktop / Laptop Web Application

---

## 🌟 Executive Overview
**JANSAAHAY (जनसहाय - Public Assistance)** is an all-in-one student financial aid ecosystem built to bridge the awareness gap in scholarship discovery. Across India and worldwide, thousands of crores in scholarship funds remain unutilized or rejected due to minor paperwork errors, missed deadlines, or lack of clear step-by-step guidance.

**JANSAAHAY** provides:
1. **Full Scope Clarity:** Every scholarship details tuition fee coverage, maintenance allowances, laptop/book grants, and direct benefit transfer (DBT) rules.
2. **Smart Eligibility Matcher:** An interactive 5-factor evaluation engine that matches students based on Course Level, Caste Category, Annual Income, Previous Marks, Gender, and Special Quotas.
3. **Interactive Document Readiness Tool:** Pre-application audit checking Aadhaar-mobile linkage, NPCI bank account seeding, Tehsildar income certificates, and Bonafide certificates.
4. **Step-by-Step Application Walkthroughs:** Detailed guides with official portal links, avoiding common rejection traps.
5. **Application Tracker:** Personal offline-first dashboard to monitor deadlines, application stages, and college verification milestones.
6. **Portal Guides & State Directory:** Direct mapped links for National Scholarship Portal (NSP OTR) and 12 state scholarship portals (Karnataka SSP, MahaDBT, UP Scholarship, eKalyan, etc.).
7. **Saahay Mitra (सहाय मित्र) Counselor:** Interactive advisory widget addressing student dilemmas in real-time.

---

## 📱 Responsive & Mobile-First Design
- **Smart Mobile Layout:** Dedicated mobile drawer, touch-friendly tap targets, and horizontal scrollable category pills.
- **Laptop / Desktop Layout:** Full wide-screen dashboard, side-by-side eligibility comparison, and interactive modals.
- **Print / PDF Summary:** 1-click printable scholarship briefs for students to bring to Cyber Cafes / CSC centers / College desks.
- **Dark Mode Support:** Auto-detects system theme with one-click manual toggle.

---

## 🚀 Key Features & Modules

| Module | Description | Key Highlight |
|---|---|---|
| **Smart Matcher** | 3-step evaluation wizard | Calculates exact % match and potential grant amount |
| **Full Scope Hub** | Detailed repository of Central, State & CSR schemes | Breakdown of maintenance allowance & tuition grants |
| **Document Audit** | 7-point readiness checklist | Step-by-step guidance on how to obtain missing certificates |
| **Personal Tracker** | LocalStorage application milestone tracker | Track from "Considering" to "Sanctioned & Disbursed" |
| **NSP OTR Guide** | Visual step roadmap for One Time Registration | FaceRD app, 14-digit ID, AISHE mapping |
| **NPCI / DBT Guide** | Clear instructions on Aadhaar bank seeding | Resolves 90% of DBT payment failure errors |
| **Saahay Mitra** | Interactive FAQ advisor | Instant answers to backlog rules, multiple scholarships, etc. |

---

## 🛠️ Tech Stack
- **Framework:** React 18 with Vite
- **Styling:** Tailwind CSS (with custom Indian Tricolor & Glassmorphism accents)
- **Icons:** Lucide React & Custom SVG
- **Interactions:** Canvas Confetti for celebration feedback
- **Storage:** Offline-first LocalStorage (zero external database / credit overhead required)

---

## 💻 How to Run Locally

### Prerequisites
- Node.js (v18 or higher)
- npm

### Installation & Execution
```bash
# 1. Clone repository
git clone https://github.com/dharshanmende-afk/JANSAAHAY.git
cd JANSAAHAY

# 2. Install dependencies
npm install

# 3. Start local development server
npm run dev

# 4. Open in browser (accessible on mobile on the same Wi-Fi)
http://localhost:3000
```

### Windows 1-Click Launch
Double-click `start.bat` in the root folder.

### Building for Production
```bash
npm run build
npm run preview
```

---

## 👤 Author & Acknowledgements
- **Developer:** [dharshanmende-afk](https://github.com/dharshanmende-afk)
- **Portal References:** National Scholarship Portal (scholarships.gov.in), AICTE, PFMS, UIDAI, and State Welfare Departments.

*Built with ❤️ to ensure no deserving student drops out due to lack of financial aid.*
